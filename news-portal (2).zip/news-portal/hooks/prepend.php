<?php
require_once dirname(__DIR__).'/bootstrap/init.php';
require_once dirname(__DIR__).'/frontend/layouts/header.php';
require_once dirname(__DIR__).'/frontend/layouts/nav.php';
?>