<?php 
$hooks['prepend']=
$hooks['append']=
?>