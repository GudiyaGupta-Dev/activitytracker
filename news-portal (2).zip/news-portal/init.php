<?php
#note:: in laravel same file is called :kernel.php,boot.php,core.php
#bootstrap : folder:intialisation of the Applications.
?>