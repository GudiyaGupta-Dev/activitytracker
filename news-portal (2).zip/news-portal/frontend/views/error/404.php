<?php
?>
<hr>
<div style="height:auto;width:100%;border:3px solid black;background:white;box-shadow:2px 2px 5px black;margin-top:12%;">
<center>
   <h1><b>404,Page Not Found!!!</b></h1>
   <h4>The URL you searched does not exist
   ?search=<?php echo basename($_SERVER['REQUEST_URL']); ?></h4>
   <a href="#">Back to Home</a>
   </center>
</div>	
</hr>