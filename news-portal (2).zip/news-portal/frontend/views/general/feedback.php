
<h1 class="fs-1 text-center p-5"><b style="color:#B71C1C">Contact <i class="fa-solid fa-phone-volume"></i></b></h1>
<div class="col-sm-3"></div>
<div class="col-sm-6">
<form>First Name<br/>
<input type="text" class="form-control" placeholder="First Name"/>
Last Name<br/>
<input type="text" class="form-control" placeholder="Last Name"/>
Email Address<br/>
<input type="email" class="form-control" placeholder="Email">
Mobile Number <br/>
<input type="number" class="form-control" placeholder="Mobile"/>
Message <br/>
<textarea class="form-control" placeholder="Message" class="area"></textarea><br/>
<input type="submit" class="btn view" value="Send Your Message"/>
</form>
</div>
<div class="col-sm-3"></div>
