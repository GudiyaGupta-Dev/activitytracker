<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/pm.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>BJP is uncivilised & anti-democracy: Siddaramaiah on BJP MLAs’ conduct in Karnataka assembly</h1><hr/>
<p id="news">
Earlier this month, Prime Minister Narendra Modi was in France as the guest of honour for the French National Day, which falls on July 14. On this day, in 1789, the people of France stormed the Bastille and inaugurated the formation of the French Republic. To commemorate this event, a military parade is held every year on the Champs-Élysées. As a diplomat, I accompanied former PM Rajiv Gandhi when the 200th anniversary was celebrated in 1989.<br/><br/>
But this column is not on foreign affairs or the importance of Indo-French relations. It is about the difficulty for non-French speakers to get the pronunciations of French words right! This became evident in the widespread TV reporting in India on PM Modi’s visit. Many of our reporters found it difficult to say Champs-Élysées correctly, since whatever its spelling, the correct way to say it is ‘Shohnz-Eh-lee-zeh’. The same problem occurred with the word Bastille. Do you pronounce it ‘Basti-ee’ or is it simply ‘Bas-still’?<br/><br/>

The more westernized of our compatriots sniggered—including on social media—at the linguistic ‘illiteracy’ of our journalists, who made the unforgivable boo-boo of mangling a beautiful language like French.<br/><br/>

While they are entitled to their snobbish derision, have they ever paused to think what the others—including the western countries—do to our words? I recall that in 2005 when I was posted in London, Indian economist Montek Singh Ahluwalia was visiting to deliver the 27th Nehru Memorial Lecture. At that time, he was the deputy chairman of the Planning Commission, which carried the rank of a cabinet minister. He also held the reputation of being a world-class economist.<br/><br/>
The hall was packed with leading members of the Indian community, along with economists and leaders of the corporate world. There was pin-drop silence as Lord Romsey, the chairperson of the Nehru Memorial Trust and the grandson of India’s last viceroy, Lord Mountbatten, stood up to introduce the distinguished guest. But there was a problem. Lord Romsey could not get the pronunciation of Ahluwalia right. Every time he tried to, his tongue tripped. Some audience members found it funny, as did, I got a distinct impression, Lord Romsey as well. Montek Ahluwalia stood sheepishly on stage in his smart blazer and tie, being a product of St Stephens College and Oxford. Finally, Lord Romsey gave up, and by way of explanation said: “I knew I wouldn’t get it right”.<br/><br/>
Why couldn’t Lord Romsey get Mr Ahluwahlia’s name right? Some would argue that such a question should not even be asked. After all, Indian names are not easy to pronounce. But equally, perhaps, Romsey 'saheb' could have practiced a little more to say ‘Ah-lu-walia’. But if he did not, it was no great matter. Montek, he knew, would be most forgiving. He was ‘one of us’, really, speaking English with the right accent, and from a similar background. And there was no worry that he would pronounce Romsey wrong. Not only because—in this instance—Romsey was an easier word to pronounce, but also because it was ‘expected’ that an Indian with the ‘right’ education should not make such a mistake. He would call ‘Warwick’ ‘Warrik’, and not ‘War-wick’ as the phonetic spelling would warrant. He would naturally know that ‘Yorkshire’ must be pronounced as ‘Yorksher’ and never as ‘York-shire’, and that ‘Edinburgh’ is actually ‘Edin-borough’.<br/><br/>
But is this knowledge of western names, for the lack of which our less anglicized citizens are ridiculed, reciprocated by our friends from the West? On the contrary, I am perpetually surprised that even well-educated people in the West, who claim to know India well, make little effort to focus on pronunciation. The irony is that we absolutely understand their ignorance. They do not feel embarrassed, nor do we take it as an affront, when our cities or festivals or the names of Indians are routinely mispronounced. Shockingly, even Mahatma Gandhi ends up being mispronounced as ‘Gandi’, and is spelt in leading publications as ‘Ghandi’.<br/><br/>
The fact of the matter is that there is an asymmetry in cultural responses: We are supposed to know how their names should be pronounced, whereas if they can pronounce ours, we are grateful, even proud. This lack of a level playing field is part of the continuing inequities of the post-colonial world and unfortunately, sometimes erstwhile colonized elites are complicit in perpetuating it.<br/><br/>
All languages need to be respected. But the inability to speak exactly like those in their mother tongue, is not necessarily a reflection of the lack of refinement or upbringing, especially since our own languages are routinely mutilated by even well-meaning foreigners, who make no real effort — as Montek Ahluwalia realised — to do better. Winston Churchill did his best to learn French. But in a famous quote, he once told British army general, Jack Seely: “Jack, when you cross Europe you land at Marsai, spend a night in Lee-on and another in Par-ee, and, crossing by Callay, eventually reach Londres. I land at Mar-sales, spend a night in Lions, and another in Paris, and come home to London.”
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>