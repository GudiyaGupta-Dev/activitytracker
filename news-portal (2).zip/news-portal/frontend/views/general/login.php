
<div class="col-sm-8 b mx-auto">
<div class="input-group">
<i class="input-group-text mt-5"> 
<i class="fa-solid fa-user "></i>
</i>

<input type="text" class="form-control mt-5" placeholder="username or email "/>
</div>
<div class="input-group">
<i class="input-group-text mt-3"> 
<i class="fa-solid fa-lock"></i>
</i>

<input type="password" class="form-control mt-3" placeholder="password"/>
</div>

 <input type="checkbox" class="mt-4"/> Remember me</br>
 <form>
<input type="submit" value="Login" class="mt-3 btn form-control" style="background:#c0302e; border: none; color:white; height:35px;border-radius:3px;"/>
</form>
</div>
</div>
