<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<!--Content-->
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/news1.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>NSA heads to Joburg to meet Chinese diplomat Yang Jiechi at BRICS NSA summit</h1><hr/>
<p id="news">
National Security Advisor Ajit Doval will be meeting senior Chinese diplomat Yang Jiechi and Nikolai Patrushev , Secretary of Russian Security Council, among others at the sidelines of the BRICS NSA meeting in Johannesburg on Monday.<br/><br/>
While the NSA level meeting is in the run-up to the summit on August 22-24, the meeting will be attended by special invitees like UAE National Security Advisor Tahnoun bin Zayed Al Nahyan and Saudi Arabia NSA Musaad bin Mohammed Al Aiban. The agenda of the BRICS NSA meeting is to discuss global issues like the Ukraine war, Indo-Pacific, religious radicalization and terrorism.<br/><br/>
According to sources, NSA Doval will be meeting his counterparts under the BRICS rubric but also bilaterally and in this context the exchanges between him and Yang Jiechi, former Director of the Central; Foreign Affairs Commission, will be important in the backdrop of PLA aggression in East Ladakh in May 2020.<br/><br/>
The situation in East Ladakh is rather precarious though under control as both India and China are constantly in touch with each other via military and diplomatic channels. The PLA is still to deescalate from the Line of Actual Control (LAC) in East Ladakh even though there has been disengagement of troops in Galwan, Gogra-Hot Springs and Pangong Tso lake spurs. The PLA has increased deployment in areas across the Daulet Beg Oldi sector and is still not allowing the Indian Army to legitimately patrol Depsang Bulge area as well as Charding Ninglung Nullah (CNN) junction in Demchok.<br/><br/>
While NSA Doval is expected to raise the issue of de-escalation in western and eastern sector of the LAC, little outcome is expected out of the bilateral parleys as the PLA is still to send back six combined armed brigades which they deployed during the 2022 National Party Congress. These six brigades are deployed across the hyper-sensitive Silliguri corridor and across the Arunachal Pradesh sector, particularly Tawang. It is because of the new PLA threat in the eastern sector that the Indian Army has put in a lot of military muscle in the sector to counter the challenge.<br/><br/>
NSA Doval will be meeting his close friends Russian, UAE and Saudi Arabia NSAs and exchange thoughts about the on-going Ukraine war and its impact on global economy. He will also be briefing Patrushev, right hand man of President Vladimir Putin, about the situation in East Ladakh as well as the Indo-Pacific. The politically unstable situation in Afghanistan and its impact on terrorism emanating from the Af-Pak region will also figure prominently in the BRICS NSA meeting.<br/><br/>
With Russian President Putin ruling out his presence at the August BRICS summit, the call will also be taken whether the summit be held physically or virtually through video conferencing.
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>