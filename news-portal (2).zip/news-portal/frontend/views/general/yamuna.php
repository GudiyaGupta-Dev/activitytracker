<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<!--Content-->
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/slider1.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>Delhi Yamuna breaches danger mark again, to rise further by evening; water enters Noida houses: Updates</h1><hr/>
<p id="news">
A flood-like situation again looms over Delhi, the water level of Yamuna river in the national capital yet again breached the evacuation mark of 206 metres with the peak level at 206.01m at 10am in Delhi Railway Bridge on Sunday, according to the Central Water Commission.<br/>
The update also warned that it is expected for the river to breach 206.7 metres — the level at which people are evacuated from low-lying neighbourhoods close to the river — by 4pm on Sunday. “Thereafter water level will likely to remain steady,” stated the CWC.<br/>
Till 10pm on Saturday, the river’s peak level was at 205.02 metres, just shy of the danger mark of 205.33 metres. The water released from the Hathnikund barrage in Haryana reached the national capital roughly 36 hours later.<br/><br/>
Meanwhile, the Delhi government has been on high alert due to the discharge of over 2 lakh cusecs of water from the barrage. "The situation has sparked concern, prompting the government to take proactive measures to ensure the safety and well-being of the residents," Delhi revenue minister Atishi said.<br/><br/>
To tackle the situation, the authorities have ensured adequate preparations in the central district, eastern district, or areas like Yamuna Bazar and Yamuna Khadar, the minister further said.<br/>
Officials on Saturday warned that the Yamuna water level in Delhi is likely to impact relief and rehabilitation work in the flood-affected low-lying areas of the capital.<br/><br/>
The national capital on Sunday recorded a minimum temperature of 28.9 degrees Celsius, two notches above the season's average, according to the IMD. The maximum temperature is likely to hover around 37 degrees Celsius.<br/><br/>
The weather agency has predicted a generally cloudy sky with light rain during the day.<br/><br/>
Meanwhile, the water level in the Hindon river in Uttar Pradesh's Noida rose on Saturday, submerging the nearby houses. The police reached the spot and issued an alert regarding the situation.<br/><br/>
"From Chhijarsi to Ecotech, water entered the houses in three low-lying areas. Poeple were evacuated from the houses. However, the river has not crossed the danger mark anywhere yet", said Suresh Rao A Kulkarni, additional police commissioner.<br/></br/>
Meanwhile, in Ghaziabad, at least 1,000 people were evacuated since Friday evening after the Hindon river’s flow increased by 10,575 cusecs in the last 48 hours and flooded upstream areas near Raj Nagar Extension, officials aware of the matter said on Saturday.<br/><br/>
The authorities also began fanning out to localities close to the river after states upstream including Himachal Pradesh and Uttarakhand received heavy rainfall, bringing back the threat of floods that threw life out of gear a little over a week ago. The India Meteorological Department (IMD) has predicted heavy to very heavy rain in parts of Himachal Pradesh and Uttarakhand till July 25.<br/><br/>
Parts of the national capital have been grappling with waterlogging and flooding for more than a week now. Initially, a downpour caused intense waterlogging on July 8 and 9, with the city receiving 125% of its monthly rainfall quota in just two days.
</p>
</div>
</div>
<!--end content-->
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>