<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<!--Content-->
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/news2.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>'Ahmedabad airport flooded' after heavy rain; passengers wade through knee-deep water</h1><hr/>
<p id="news">
Sardar Vallabhai Patel Airport was flooded with knee-high water after incessant rainfall across in Gujarat in the last two days.<br/>
Ahmedabad's Sardar Vallabhai Patel Airport in Gujarat was reportedly flooded with knee-high water on Saturday night after incessant rainfall across the state in the last two days. Several social media users, including Congress leaders, shared videos which showed the airport purportedly flooded, with runways and terminal areas submerged under water.<br/><br/>
The waterlogging at the airport has led to passengers facing trouble in reaching for their flights on time while authorities have asked the passengers to check in with their airlines about their flights.<br/><br/>
Congress national coordinator Deepak Khatri shared a video of a waterlogged road apparently outside the Ahmedabad airport terminal.<br/><br/>
This is the situation of Ahmedabad airport, #Gujarat after 28 years of BJP rule. This is the model state of Narendra Modi,” he tweeted.<br/><br/>
Another user @punitjuneja shared a video of the terminal, saying, “This is Adani managed Airport, Ahmedabad, Gujarat.”<br/><br/>
Heavy to very heavy rain pounded several districts in Gujarat’s south and Saurashtra regions on Saturday, triggering a flood-like situation in urban areas and isolating villages amid rising water levels in dams and rivers surging to danger levels.<br/><br/>
The National Defence Response Forces (NDRF) team on Saturday conducted a rescue operation in the Junagadh district of the region. The NDRF personnel in the rescue operation reached out to the general public and assisted them to cross the city's flooded and waterlogged regions into safer areas.<br/><br/>
In Junagadh, dozens of parked cars and cattle were swept away in gushing waters after it received 219 mm of rain in 8 hours till 4pm on Saturday. People were seen wading through waist-deep water to shift to safer places, while some of them were rescued by volunteers as they were carried away in strong currents.<br/><br/>
Navsari and Junagadh were among the worst affected districts due to the torrential downpours that led to a deluge in several residential pockets and marketplaces.<br/><br/>
Authorities requested people to take precautions and urged them to contact the control room in case of any untoward incident or emergency situation. People were warned to not visit dams and surrounding areas.<br/><br/>
Heavy showers also caused traffic jams on the Mumbai-Ahmedabad national highway near Navsari due to flooding, officials said.<br/><br/>
In another incident, a father-son duo drowned after their car got washed away near Silvassa town of Dadra and Nagar Haveli district in the Union Territory neighbouring Gujarat. The two were caught by fast-moving waters on Friday night when they were trying to cross over a low-lying bridge.<br/><br/>
A rescue team recovered the car and their bodies inside the vehicle on Saturday afternoon, an official said.<br/><br/>
Devbhumi Dwarka, Bhavnagar, Bharuch, Surat, Tapi, Valsad and Amreli were among other districts that received heavy rainfall on Saturday, the SEOC said.<br/><br/>
The India Meteorological Department (IMD) has issued a warning of heavy to very heavy rainfall with isolated extremely heavy rainfall in south Gujarat and Saurashtra-Kutch districts till Sunday morning. Heavy to very heavy rainfall will continue in many other districts of south Gujarat and Saurashtra-Kutch during the next three days, the IMD said.<br/><br/>
The IMD also warned fishermen to not venture along and off the north Gujarat coast from July 22 to July 26 saying squally weather conditions were very likely to prevail during this period.
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>