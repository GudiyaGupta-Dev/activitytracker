<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/news6.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>Hoarding game! Indians in US and Canada stock up rice after govt bans export, long queues outside grocery stores</h1><hr/>
<p id="news">
However, interestingly, Basmati rice which doesn't fall under the ban is also being hoarded by the people.<br/><br/>Government of India's decision to ban export of non-basmati rice has triggered a hoarding race among Indian-Americans. According to several tweets going viral on social media, Indians living in US are rushing to ‘panic buy’ white rice.<br/><br/>
However, interestingly, Basmati rice which doesn't fall under the ban is also being hoarded by the people. Probably, Indian-Americans are buying huge quantities under the wrong assumption that Basmati rice has also been banned. Or there is a possibility that they might be expecting an export ban on Basmati rice too in near future, causing them to take a precautionary measure. The bulk buying is leading to black marketing of Basmati rice in the US, at high prices.<br/><br/>
Another Twitter user pointed to the affluence of Indian-American community in the US as they are able to buy such huge quantity of Basmati rice which is considered a premium product.<br/><br/>
"A lot of WhatsApp University forwards are like "life is very difficult in America and Canada" and yeah, not minimizing immigrant struggles, but let's take a step back and note what a moment of collective affluence this is. We are having a run on Basmati rice! A premium product!," tweeted the user.<br/><br/>
Notably, On Thursday, India put a ban "with immediate effect" on the export of non-basmati white rice (Semi-milled or wholly milled rice, whether or not polished or glazed). The Ministry of Consumer Affairs, Food and Public Distribution said, “In order to ensure adequate availability of non-basmati white rice in the Indian market and to allay the rise in prices in the domestic market, Government of India has amended the Export Policy of the above variety from ‘Free with export duty of 20%’ to ‘Prohibited’ with immediate effect.”<br/><br/>
India's move was done to curtail the price rise of non-basmati white rice at home. According to the ministry, "retail prices have increased by 11.5% over a year and 3% over the past month".<br/><br/>
In September 2022, India had imposed an export duty of 20% on the commodity but despite it, the export of non-basmati white rice increased from 33.66 LMT (Sept-March 2021-22) to 42.12 LMT (Sept-March 2022-23) which ultimately affected prices and availability locally in India.<br/><br/>
Indian Government has not made any change in the export policy of non-basmati rice (par boiled rice) and basmati rice. India which fulfils 40% of the rice needs across the world and non-basmati white and broken rice, accounted for around 10 million tons of a total of 22 million tons of Indian rice exports last year. The buyers are expected to move to Thailand and Vietnam, but their 5% broken rice could cost $600 per metric ton.<br/><br/>
"India would disrupt the global rice market with far greater velocity than Ukraine did in the wheat market with Russia's invasion," B.V. Krishna Rao, president of the Rice Exporters Association told Reuters.
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>