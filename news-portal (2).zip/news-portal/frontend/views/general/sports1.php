<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/sports1.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>‘India emerged as a centre of global trust and attraction’: PM Modi at Rozgar Mela. Top quotes</h1><hr/>
<p id="news">
Jamaica produced one of the biggest surprises of the Women’s World Cup on Sunday by holding France to a 0-0 draw.<br/><br/>
France's Kadidiatou Diani struck the bar with a 90th-minute header, but one of the tournament favorites had to settle for a point.<br/><br/>
The draw saw Jamaica pick up its first ever point in the competition, despite ending the game with 10 players after Khadija Shaw was sent off in time added on.<br/><br/>
In a game of few chances, Diani had France's best opportunities to score a winner, but could not find a breakthrough at the Sydney Football Stadium.<br/><br/>
She forced a save from Jamaica goalkeeper Rebecca Spencer in the first half and saw another effort deflected wide.<br/><br/>
Another header in the second half also went wide of the target before her late effort came back off the bar.<br/><br/>
France, a quarterfinalist in 2019, is ranked fifth in the world, while Jamaica is 43rd.<br/><br/>
The French were expected to be too strong for Jamaica, which is playing in the tournament for the second time, having lost all of its games at its debut in 2019 with a goal difference of -11.<br/><br/>
But favorites have not had everything their own way so far in the tournament and France was the latest to struggle against an underdog.<br/><br/>
Australia needed a penalty to get a 1-0 win against Ireland, while European champion England also needed a spot kick to overcome Haiti 1-0. Nigeria held Olympic champion Canada 0-0.<br/><br/>
Jamaica did well to disrupt a France team that struggled to put together fluid moves.<br/><br/>
In one of France’s few moments of quality in the first half, Diani saw a low effort bundled around the post by Spencer. From the resulting corner, Wendie Renard headed over from close range.<br/><br/>
Kadidiatou was fractions away from giving France a halftime lead when firing from the edge of the area. Chantelle Swaby managed to get something in the way of the shot, which deflected narrowly wide with the keeper beaten.<br/><br/>
After seeing another header go wide after the break, Kadidiatou almost came up with the decisive moment when hitting the bar.<br/><br/>
Jamaica may well come to regret the red card for Shaw, who will be suspended for the next game.<br/><br/>
WHAT’S NEXT<br/><br/>
France plays Brazil in Brisbane on Saturday. Jamaica travels to Perth where it will face Panama.
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>