
<h1 class="fs-1 text-center mt-5">About <b style="color:#B71C1C">US <i class="fa-solid fa-newspaper"></i></b></h1>
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12">
<img src="images/logo.png" class="img-fluid"/>
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<p class="h5 mt-5">Bhaskar Prakashan Pvt. Ltd. is a Private Company incorporated on 01 July 1985. It is classified as Indian Non-Government Company and is registered at Registrar of Companies, Gwalior. The Company is promoted by the Jabalpur based Agarwal family, Bhaskar Prakashan Private Limited (BPPL) is engaged in the newspaper publishing business since 1985 and publishes the ‘Dainik Bhaskar’ Hindi newspaper in seven editions namely Jabalpur (Estd-1-8-1986), Satna (Estd-27-9-1993), Chindwara (Estd- 25-10-2008), Singrouli (Estd-30-11-2013) in Madhya Pradesh and Nagpur (Estd-08-12-2002) , Akola (Estd-02-09-2009) and Aurangabad (Estd-27-08-2011) in Maharashtra.
</p>
</div>
</div>
