<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/education3.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>CSIR UGC NET Result 2023 Live: Final provisional answer key out</h1><hr/>
<p id="news">
We live in a profoundly unequal world. According to statistics provided by the World Inequality Database, in 2022 the richest 10% of the global population owned 76% of all wealth, while the poorest 50% of the global population only owned 2% of the world’s wealth. About 1% of the world population owned nearly half of the world’s wealth. Digging a little deeper beneath these statistics, one also finds that the unequal distribution of wealth follows regional, racial and gender differences. This means that somebody’s wealth and living conditions depend not so much on how hard they work but mostly on where they live, what ethnicity they are and what gender they are.<br/><br/>What about the language they speak? Does it matter as much as other factors? Is there a relationship between language and inequality? Can language actually be a driver of inequality? In order to discuss the complex ways in which language may be entangled with inequality, one needs to possess a solid understanding of both the nature of language and the roles it plays in society. This kind of expertise is the essence of applied linguistics.<br/><br/>
As the name suggests, applied linguistics considers knowledge about language in general -- linguistics -- in relation to real-world applications. Originally, Applied linguistics was primarily concerned with language pedagogy and with the fundamental skills involved in mastering a foreign language. With time, however, the boundaries of the discipline expanded to include virtually all aspects of human life where language plays a role.<br/><br/>
English as a global language
<br/><br/>
Returning to the issue of inequality and to the questions posed above, the role of applied linguistics can be best illustrated by referring specifically to the English language and its forms and functions in the world today. English has a unique position globally compared to any other language. This is because of two main reasons. First, it’s the language with the greatest geographical spread -- it is used nationally and internationally in all continents, more widely than any other language, in domains as diverse as business, tourism, education, science, technology, and academia. The second reason is that most speakers of English are bilingual or multilingual and don’t live in countries that are usually considered the cultural bases of the language, such the UK, the USA or Australia. The vast majority of users of English are elsewhere and don’t even consider English their main language. The combination of these two facts is a source of inequality. Let’s explain why and how Applied Linguistics can help address these points.<br/><br/>
The global reach of English makes it a very powerful language. This has a number of consequences in terms of inequality. Let’s take education as a sector where this is particularly visible. In many parts of the world there has been a sharp rise in the number of schools and universities where the language of instruction is English. This has been largely in response to the increased global demand for English language skills in the workplace.
<br/><br/>
However, this has also created situations where, especially in schools, some students are disadvantaged as they are expected to operate in a language that they don’t speak at home and they don’t feel confident with. This then leads to those students attaining poorer academic results than they would do if they studied in their own languages. It also leads to local languages losing prestige and value, and their speakers having fewer opportunities in life in comparison to those who are confident users of English. Since English tends to be used more often by higher social classes, all of this causes a vicious cycle where the gap between the haves and the have-nots widens. Those in the upper layers of society, more likely to function in English, gain even more advantage through the use of English-medium education, while those who are already socially disadvantaged end up being even further disadvantaged through education too.<br/><br/>
Applied linguistics to counter language-based inequality
<br/><br/>
In applied linguistics, the misconception that has been highlighted in relation to English-medium education is the idea that education should be carried out in one language only. Such a misconception derives from a bias in favour of monolingualism that has its roots in the ideology propagated during European colonialism especially in the 19th century. Instead, Applied linguistics research has shown that a multilingual approach to education is effective in aiding students’ comprehension, in boosting their confidence and sense of self and, ultimately, in promoting a kind of education that is not discriminatory. Multilingualism is also more common around the world than monolingualism and it is logical for the classroom to reflect the language diversity that exists outside its four walls. This is particularly relevant in contexts such as India, where English coexists alongside many other languages.<br/><br/>
 Another related form of inequality that applied linguistics has brought to the fore is a type of discrimination whereby so-called ‘native speakers’ of English are considered linguistically superior and therefore better teachers of English compared to their counterparts who are labelled ‘non-native speakers’ of the language. The notion of the ‘(non-)native speaker’ has been challenged in applied linguistics for a long time. Many scholars have pointed out how it is entangled with racism, since what people often mean by these terms has strong racial connotations, whereby ‘native speaker’ becomes a synonym to ‘white’ and ‘non-native speaker’ a synonym to ‘non-white’. The discriminatory consequences of this have also been denounced.
<br/><br/>
All this academic work has not been fruitless. One of the most remarkable results is the fact that the widely adopted Common European Framework for Languages has recently updated its descriptors to state that the aim of language education “is no longer seen as simply to achieve ‘mastery’ of one or two, or even three languages, each taken in isolation, with the ‘ideal native speaker’ as the ultimate model [but] to ‘develop a linguistic repertory, in which all linguistic abilities have a place’.”<br/><br/>
Applied linguistics is an academic discipline but as it engages more and more with the outside world it is capable of encouraging change and promote the institution of language policies that work towards greater equality.
<br/><br/>
The author is a reader in the School of Education, Languages, and Linguistics, University of Portsmouth
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>