<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<!--Content-->
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/slider2.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>'She could've shown better manners': Bangladesh captain burns Harmanpreet for insulting home team, questioning umpiring</h1><hr/>
<p id="news">
While her deputy Smriti Mandhana defended the India captain, Bangladesh skipper Nigar Sultana hit back at Harmanpreet<br/>
The cynosure of the series or at least that deciding match at the Sher-e-Bangla National Cricket Stadium in Mirpur on Saturday should have been the drawn contest between the two Asian rivals - India and Bangladesh - but instead the the entire focus shifted on Harmanpreet Kaur's act of smashing the stumps after dismissal and later questioning the stand of umpiring in the series. While her deputy Smriti Mandhana defended the India captain, Bangladesh skipper Nigar Sultana hit back at Harmanpreet, blasting her for her poor behaviour during the 3rd ODI match.<br/><br/>
It was in the 34th over of India's chase of 226 when Harmanpreet was dismissed after Nahida Akter completed the catch. But the question remained as to whether the ball was off the bat or pads. The umpire, it seems, signalled it out after the completed catch leaving Harmanpreet infuriated as she smashed the stumps after dismissal and then had a heated exchange of words with the umpire on her way towards the dug out.<br/><br/>
There were other two instances when India were left disappointed at the umpiring standards in the match - the first involved Yastika Bhatia, who was dismissed lbw, and other involved the dismissal of Meghna Singh.<br/><br/>
After the match, Harmanpreet slammed the umpires saying: "A lot of learning from this game. Even apart from the cricket, the type of umpiring that was happening there, we were very surprised. The next time whenever we are coming to Bangladesh, we'll have to make sure we have to deal with this kind of umpiring and accordingly, we'll have to prepare ourselves."<br/><br/>
<b>Harmanpreet blasted for insulting Bangladesh team</b><br/>
According to a report in ESPNCricinfo, Harmanpreet had called for the umpires to join the Bangladesh team for the end-of-series photograph, implying that they were part of the home team. Insulted at the remark, Nigar had a word with BCB officials and left the post-match presentation with the player.<br/><br/>
Speaking about the incident in the post-match presentation, Nigar hit back at Harmanpreet for her poor conduct, explaining that her words made the Bangladesh team uncomfortable for the photograph session and hence they had left.<br/><br/>
"It is totally her problem. I have nothing to do with it. As a player, she could have shown better manners. I can't tell you what happened, but it didn't feel right to be there [for the photograph] with my team. It wasn't the right environment. That's why we went back. Cricket is a game of discipline and respect," she said.<br/><br/>
About the umpiring, Nigar said, "The umpires wouldn't give her out if she wasn't out. We had umpires from men's international cricket, so they were good umpires. What are they [India] going to say about the caught or run-out dismissals [of which there were six excluding the Harmanpreet and Meghna wickets]? We have respected their decisions. The umpire's decision is the final decision, whether I like it or not. Why didn't we behave in that way [like the India players]?"
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>