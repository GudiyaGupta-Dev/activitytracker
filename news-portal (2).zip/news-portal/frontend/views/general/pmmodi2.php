<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/pm2.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>‘India emerged as a centre of global trust and attraction’: PM Modi at Rozgar Mela. Top quotes</h1><hr/>
<p id="news">
Prime Minister Narendra Modi on Saturday said the citizens have taken a resolution to make India a developed nation and expressed a great honour for being a government employee.<br/><br/>
In a virtual event of the Rozgar Mela, Modi distributed over 70,000 appointment letters to the newly inducted employees. Addressing the new appointees, Modi said, “Today, every expert believes that India in a few years would be in the world's top three economies.”<br/><br/>
The Rozgar Mela was organised at 44 locations across India and the new recruits would be joining the government in various ministries/departments across central and state governments. “The Rozgar Mela is expected to act as a catalyst in further employment generation and provide meaningful opportunities to the youth for their empowerment and participation in national development,” a statement from the PMO said on Friday.<br/><br/>
The first phase of the 'Rozgar Mela', a key campaign to provide 10 lakh government jobs was launched on October 22, 2022, by Modi.<br/><br/>
<b>Top quotes from PM Modi's address at Rozgar Mela:</b><br/>
1. “During the 'Azadi ka Amrit Mahotsav', when the country is working on the path of development, it is a great honour to get the opportunity to work as a government employee.”<br/><br/>
2. “The people of this country have taken the resolution to make India a developed country.”<br/><br/>
3. “Today every expert is saying that in a few years, India will be in the world's top three economies. This means employment opportunities and citizen's per capita income will increase.”<br/><br/>
4. “Today India is one of those countries where the banking sector is considered to be the strongest.”<br/><br/>
5. Lashing out at the UPA's previous government, Modi said, "Our banking sector has seen massive destruction during the previous government. Today, we are able to make digital transactions but 9 years ago, phone banking was not for 140 crore people."<br/><br/>
6. “Public sector banks were earlier known for losses running into thousands of crores of rupees and non-performing assets (NPAs), but now they are known for record profits.<br/><br/>”
7. “The 'phone banking scam' was one of the biggest scams during the previous government where people who were close to a specific family used to call Banks and provided them loans worth thousands of crores and these loans were never repaid.”<br/><br/>
8. “India has emerged as a centre of global trust and attraction, and the country has to make full use of it.”<br/><br/>
9. “Our government took several measures, including strengthening the management of banks, merging small banks and injecting professionalism, to help the banking sector.”<br/><br/>
10. While praising the banking sector employees for their hard work, he said, "They commit to serve people and execute various government schemes to help the poor and unorganised sectors through loans under the 'Mudra' scheme and to support women self-help groups."<br/><br/>
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>