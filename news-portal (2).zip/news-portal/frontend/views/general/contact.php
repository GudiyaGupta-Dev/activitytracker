
<h1 class="fs-1 text-center p-5"><b style="color:#B71C1C">Contact <i class="fa-solid fa-phone-volume"></i></b></h1>
<div class="col-sm-3 ps-5">
<form>First Name<br/>
<input type="text" class="form-control" placeholder="First Name"/>
Last Name<br/>
<input type="text" class="form-control" placeholder="Last Name"/>
Email Address<br/>
<input type="email" class="form-control" placeholder="Email">
Mobile Number <br/>
<input type="number" class="form-control" placeholder="Mobile"/>
Message <br/>
<textarea class="form-control" placeholder="Message" class="area"></textarea><br/>
<input type="submit" class="btn view" value="Send Your Message"/>
</form>
</div>
<div class="col-sm-3 mt-5"></div>
<div class="col-sm-5">
<i class="fa-solid fa-location-dot"></i>
<b id="b">Office Address</b><br/>
<p id="bt">Plot No-44, Behind H.P Petrol Pump, Tedhi Pulia Ring Rd, Sector 5, Vikas Nagar, Lucknow, Uttar Pradesh 226022</p>
<i class="fa-solid fa-phone-volume"></i>
<b id="b">Mobile Number</b><br/>
<p id="bt">+91-8574326585<br/>
+91-8574326585</p>
<i class="fa-regular fa-envelope"></i>
<b id="b">Mail Us</b><br/>
<p id="bt">info@bhaskartimes.in<br/>
hr@bhaskartimes.in</p>
</div>
</div>
