<html>
<head>
<link href="css/bootstrap.css" rel="stylesheet"/>
<link href="css/all.css" rel="stylesheet"/>
<style>
.ico{
font-size:22px;
padding:2px;
transition:all 1s;
}
:root{
--mycolor:linear-gradient(45deg,#B71C1C,#B71C1C);
--txtmycolor:#f50057;
}
.txt-mycolor{
color:var(--txtmycolor);
}
.bg-mycolor{
background:var(--mycolor);
}
#menu ul{
margin:0px auto;
font-size:22px;
}
.navbg{
background:white;
}
#menu ul li a{
color:#B71C1C !important;
}
#news::first-letter{
font-size:300%;
color:#B71C1C;
}
</style>
</head>
<body>
<div class="container-fluid">
<div class="row ttop bg-light text-center py-1 bg-mycolor text-light">
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-solid fa-envelope"></i>
info@bhaskartimes.in
</div>
<div class="col-lg-6 col-md-6 col-sm-12">
<i class="fa-brands fa-facebook ico"></i>
<i class="fa-brands fa-twitter ico"></i>
<i class="fa-brands fa-youtube ico"></i>
<i class="fa-brands fa-instagram ico"></i>
</div>
</div>
<div class="row">
<div class="col-sm-12 font">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
</div>
<div class="row">
<div class="col-sm-12 navbg">
<!--start menu-->
<nav id="menu" class="navbar navbar-expand-lg navbar-light m-0 p-0">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.html">
		  <i class="fa-solid fa-house"></i>
		   Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html"><i class="fa-solid fa-circle-info"></i> About Us</a>
        </li>        
		<li class="nav-item">
          <a class="nav-link" href="Newsmenu.html"><i class="fa-solid fa-newspaper"></i> News</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
           <i class="fa-solid fa-image"></i> Gallery
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item disabled" href="vdogal.html">Video</a></li>
            <li><a class="dropdown-item disabled" href="imggal.html">Image</a></li>
          </ul>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="contact.html"><i class="fa-solid fa-envelope"></i> Contact Us</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="blog.html"><i class="fa-solid fa-blog"></i> Blog</a>
        </li>
		<li class="nav-item">
          <a class="nav-link" href="Feedback.html"><i class="fa-solid fa-comment"></i> Feedback</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="login.html"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--end menu-->
</div>
</div>
<div class="row">
<div class="col-sm-12 col-lg-4 col-md-4">
<Img src="images/poli1.jpg" class="img-fluid"/>
</div>
<div class="col-sm-12 col-lg-8 col-md-8">
<h1>BJP, JD(S) boycott Assembly proceedings in protest against suspension of 10 MLAs</h1><hr/>
<p id="news">
The opposition BJP and JD(S) boycotted the Karnataka Legislative Assembly for the second day after 10 BJP members were suspended for their conduct.<br/>
The opposition BJP and the JD(S) boycotted proceedings of the Karnataka Legislative Assembly for the second day on Friday, after the Speaker suspended 10 BJP members for the remainder of the session, for their "indecent and disrespectful" conduct in the House.<br/><br/>
Today is the last day of the legislature session that began on July 3. BJP legislators staged a sit-in demonstration in front of the Gandhi statue at Vidhana Soudha and raised slogans against the government and the Speaker U T Khader. A joint delegation of both BJP and JD(S) had on Thursday petitioned Karnataka Governor Thaawarchand Gehlot regarding the "functioning" of the Congress government in the state, its "suppressive and dictatorial" nature, and also the conduct of the Speaker.<br/><br/>
The Speaker too had met the Governor along with Deputy Speaker Rudrappa Lamani and submitted to him a report regarding the proceedings in the Assembly on Wednesday. The Assembly on Wednesday witnessed chaotic and unruly scenes as angry BJP legislators tore copies of bills and the agenda and threw them at Lamani, who was presiding, following which the Speaker Khader suspended 10 of them for the remainder of the session.<br/><br/>
The 10 BJP legislators who have been suspended for the remainder of the session for their "indecent and disrespectful conduct" in the House are -- C N Ashwath Narayan, V Sunil Kumar, R Ashoka, Araga Jnanendra (all former ministers), D Vedavyasa Kamath, Yashpal Suvarna, Dheeraj Muniraj, A Umanath Kotian, Arvind Bellad and Y Bharath Shetty.<br/><br/>
They were suspended after the House adopted a motion to this effect on Wednesday. In turn, MLAS of the opposition BJP and JD(S) gave notice of no-confidence against the Speaker to the Assembly Secretary.<br/><br/>
The turn of events had unfolded as opposition BJP and JD(S) members protested from the well of the House, accusing the Congress government of deputing 30 IAS officers to "serve" its alliance leaders, who had met in the city on Monday and Tuesday in the city, to strategize for the 2024 Lok Sabha election.
</p>
</div>
</div>
<!--Footer-->
<div class="row">
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark p-4">
<center>
<img src="images/logo.png" class="img-fluid" style="max-height:150px;"/>
</center>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<p class="text-light p-4">Bhaskar Times, is an Indian English-language daily newspaper and digital news media owned and managed by Bhaskar Times Group. It is the fourth-largest newspaper in India by circulation and largest selling English-language daily in the world.</p>
</div>
<div class="col-lg-4 col-md-6 col-sm-12 text-bg-dark">
<img src="images/play.png" class="img-fluid pt-4" style="max-height:100px;"/><br/>
<img src="images/gem.png" class="img-fluid pt-2" style="max-height:85px;"/>
</div>
</div>
<!--footer end-->
</div>
<script src="js/bootstrap.bundle.js"></script>
</body>
</html>