<?php
define('BASE_URL','http://localhost/news-portal/');
define('PROJECT_PATH',dirname(__DIR__));
//echo PROJECT_PATH;
//echo BASE_URL;

return[
     'database'=>[
        'hostname'=>'localhost',
        'username'=>'root',
        'password'=>'',
        'dbname'=>'my_db',
        'port'=>3360		
   ]
];
?>