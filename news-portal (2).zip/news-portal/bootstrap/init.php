<?php
#note:: in laravel same file is called :kernel.php,boot.php,core.php
#bootstrap : folder:intialisation of the Applications.
$config=include_once dirname(__DIR__).'/config/settings.php';
require_once PROJECT_PATH.'/helper/functions.php';
//print_r($config);
$hostname= $config['database'] ['hostname'];
$username= $config['database'] ['username'];
$password= $config['database'] ['password'];
$dbname= $config['database'] ['dbname'];
$port= $config['database'] ['port'];
// echo '<pre>';
// print_r(get_defined_vars()); //All defined variable
// print_r(get_defined_constants()); //All the pre-defined and underdefined constants
// print_r(get_defined_functions()); //All the prefined functions (internal or 1227) and userdefined 
//-----------include routes file---------------------------
require_once PROJECT_PATH.'/routes/web-routes.php';
require_once PROJECT_PATH.'/routes/api-routes.php';

?>