<?php
#we will url to file........
$webRoutes['DEFAULT_ROUTE']='/frontend/views/general/home.php';
$webRoutes['404_ERROR_ROUTE']='/frontend/views/error/404.php';
$webRoutes['/'] ='/frontend/views/general/home.php';
$webRoutes['/home'] ='/frontend/views/general/home.php';
$webRoutes['/about-us'] ='/frontend/views/general/about.php';
$webRoutes['/contact'] ='/frontend/views/general/contact.php';
$webRoutes['/news'] ='/frontend/views/general/newsmenu.php';
$webRoutes['/blog'] ='/frontend/views/general/blog.php';
$webRoutes['/feedback'] ='/frontend/views/general/feedback.php';
$webRoutes['/login'] ='/frontend/views/general/login.php';

?>